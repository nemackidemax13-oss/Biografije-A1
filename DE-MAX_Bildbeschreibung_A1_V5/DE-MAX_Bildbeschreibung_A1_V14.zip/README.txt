DE-MAX - OPIS SLIKE A1 - VERZIJA V14
===================================
Paket sadrži:
- index.html : kompletna V14 aplikacija sa ugrađenim spiskom 40 slika

Pokretanje:
1. Raspakujte ZIP.
2. Otvorite index.html u pregledaču ili ga postavite na GitHub Pages.
3. Za slike je neophodan internet: preuzimaju se sa javnog GitHub repozitorijuma DE-MAX A1-nivo.
4. Za AI proveru i transkripciju potreban je zaseban, podešen serverski URL (npr. Replit). API ključ se ne upisuje u HTML fajl.

Mobilni prikaz 9:16, povećana fotografija, crvena strelica Nazad, plavi izbor fotografija.
